﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace guessing_game
{
    class Program
    {
        static void Main(string[] args)
        {
            int userInput;

            string[] contentArray1 = new string[4];

            contentArray1[0] = "Blast off to the Asteroid Belt!";

            contentArray1[1] = "Explore the rings of Saturn!";

            contentArray1[2] = "Build a Dyson Sphere around the sun!";

            contentArray1[3] = "Drill to explore the underground oceans of Enceladus!";

            Header();

            firstChoice();

            userInput = Convert.ToInt16(Console.ReadLine());

            if (userInput == 1)
            {
                Console.Clear();
                Console.WriteLine(contentArray1[0]);
                Console.ReadLine();
            }
            else
            {
                Console.Clear();
                Console.WriteLine(contentArray1[1]);
                Console.ReadLine();
            }

            SecondChoice();

            userInput = Convert.ToInt16(Console.ReadLine());

            switch (userInput)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine(contentArray1[2]);
                    break;

                case 2:
                    Console.Clear();
                    Console.WriteLine(contentArray1[3]);
            }


            Console.ReadLine();

        }

        static void Header()
        {
            Console.WriteLine("Welcome Adventurer!\n");
        }

        static void firstChoice()
        {
            Console.WriteLine("You have just joined the International Space Corps. What will be your first adventure?\n");
            Console.WriteLine("Choose one of the options below:\n");
            Console.WriteLine("1) Asteroid Belt");
            Console.WriteLine("2) Saturn");
        }

        static void SecondChoice()
        {
            Console.WriteLine("You have just completed your first mission! Choose the location for your second mission:\n");
            Console.WriteLine("Choose one of the options below:\n");
            Console.WriteLine("1) Enceladus");
            Console.WriteLine("2) Sun");
        }
    }
}
